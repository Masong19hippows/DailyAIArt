Periodically Change Your Wallpaper With AI Generated Art.

This extension web-scrapes the images form Nightcafe [and edits them] and displays them as a wallpaper on ChromeOS. If you want a real-time look at what each setting affects, go to https://creator.nightcafe.studio/explore and play around. 

The options include sort, blur, and filter. The sort and filter are pretty much exactly from Nightcafe. While grabbing the image, the image is also converted to a 16:9 ratio and the remaining pixels are taken up by a blurred version of the image. The blur can be adjusted in settings. 

All Icons supplied by icons8 at https://icons8.com/icon/5RSNkT2QWYy3/bmo